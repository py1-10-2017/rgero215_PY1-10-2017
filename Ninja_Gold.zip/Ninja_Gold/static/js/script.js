$(document).ready(function () {
    $(".btn").on("click", function () {
        $(".redirect").atrr("action", "/process_money")
    })
    return false
})
